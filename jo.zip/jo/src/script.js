// Skill animation when clicked

document.querySelectorAll(".skill-box").forEach(skill => {

  skill.addEventListener("click", () => {

    skill.style.transform = "rotateY(360deg)";

    setTimeout(() => {

      skill.style.transform = "scale(1.1)";

    }, 600);

  });

});